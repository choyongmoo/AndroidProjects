package com.loch.meetingplanner.domain.user.model;

public enum FriendStatus {
    PENDING,
    ACCEPTED,
    BLOCKED
}
