package com.loch.meetingplanner.domain.user.dto;

public record UserInfoResponse(String username, String email) {
}
