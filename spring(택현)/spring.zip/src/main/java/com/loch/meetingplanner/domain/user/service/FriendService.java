package com.loch.meetingplanner.domain.user.service;

public class FriendService {

}
