package com.loch.meetingplanner.domain.user.controller;

public class FriendController {

}
