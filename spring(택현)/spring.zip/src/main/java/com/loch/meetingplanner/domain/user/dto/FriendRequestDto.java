package com.loch.meetingplanner.domain.user.dto;

//매핑용
public record FriendRequestDto(String targetUserId) {} 
