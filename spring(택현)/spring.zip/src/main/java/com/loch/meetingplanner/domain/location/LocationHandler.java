package com.loch.meetingplanner.domain.location;

public class LocationHandler {

}
