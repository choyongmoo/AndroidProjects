package com.loch.meetingplanner.domain.group.controller;

public class GroupController {

}
