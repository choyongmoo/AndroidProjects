package com.loch.meetingplanner.domain.user.dto;

public class FriendAcceptDto {

}
