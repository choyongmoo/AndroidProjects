package com.loch.meetingplanner.domain.user.repository;

public class FriendRepository {

}
