package com.loch.meetingplanner.domain.group.service;

public class GroupService {

}
