INSERT INTO sample (id, message) VALUES (1, 'Hello World!');
-- DELETE FROM sample WHERE id = 1;