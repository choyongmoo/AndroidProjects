package com.loch.meetingplanner.domain.auth.dto;

public record LoginResponse(

        String username,

        String accessToken) {
}
