package com.loch.meetingplanner.domain.auth;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.loch.meetingplanner.domain.user.model.Role;
import com.loch.meetingplanner.config.security.JwtTokenProvider;
import com.loch.meetingplanner.config.security.SecurityUserDetails;
import com.loch.meetingplanner.domain.auth.dto.LoginRequest;
import com.loch.meetingplanner.domain.auth.dto.LoginResponse;
import com.loch.meetingplanner.domain.auth.dto.RegisterRequest;
import com.loch.meetingplanner.domain.user.model.User;
import com.loch.meetingplanner.domain.user.repository.UserRepository;

import jakarta.transaction.Transactional;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider jwtTokenProvider;

    public AuthService(UserRepository userRepository,
            PasswordEncoder passwordEncoder,
            AuthenticationManager authenticationManager,
            JwtTokenProvider jwtTokenProvider) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
        this.authenticationManager = authenticationManager;
        this.jwtTokenProvider = jwtTokenProvider;
    }

    @Transactional
    public LoginResponse register(RegisterRequest request) {
        if (userRepository.existsByUsername(request.username())) {
            throw new IllegalArgumentException("Username already exists");
        }

        if (userRepository.existsByEmail(request.email())) {
            throw new IllegalArgumentException("Email already exists");
        }

        User user = new User();
        user.setUsername(request.username());
        user.setEmail(request.email());
        user.setPasswordHash(passwordEncoder.encode(request.password()));
        user.setDisplayName(request.displayName());

        //추가부분
        user.setRole(Role.USER);
        
        userRepository.save(user);

        String token = jwtTokenProvider.generateToken(user);
        return new LoginResponse(user.getUsername(), token);
    }

    public LoginResponse login(LoginRequest request) {
        try {
            Authentication auth = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            request.username(), request.password()));

            // SecurityContext에 저장
            SecurityContextHolder.getContext().setAuthentication(auth);

            // 사용자 정보 가져오기
            SecurityUserDetails userDetails = (SecurityUserDetails) auth.getPrincipal();

            String token = jwtTokenProvider.generateToken(userDetails);
            return new LoginResponse(auth.getName(), token);
        } catch (BadCredentialsException ex) {
            throw new IllegalArgumentException("Invalid username or password");
        } catch (Exception ex) {
            throw new RuntimeException("Login failed");
        }
    }

}
