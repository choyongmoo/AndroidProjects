package com.loch.meetingplanner.domain.appointment.repository;

public class AppointmentRepository {

}
