package com.loch.meetingplanner.exception;

public record ErrorResponse(

        int status,

        String message,

        String path) {
}