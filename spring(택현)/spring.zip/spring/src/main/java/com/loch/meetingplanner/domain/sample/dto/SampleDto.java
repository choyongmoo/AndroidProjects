package com.loch.meetingplanner.domain.sample.dto;

public class SampleDto {

  private String message;

  public SampleDto(String message) {
    this.message = message;
  }

  public String getMessage() {
    return message;
  }
}