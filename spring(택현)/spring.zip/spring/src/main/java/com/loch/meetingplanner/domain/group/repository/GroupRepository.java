package com.loch.meetingplanner.domain.group.repository;

public class GroupRepository {

}
