package com.loch.meetingplanner.domain.appointment.service;

public class AppointmentService {

}
